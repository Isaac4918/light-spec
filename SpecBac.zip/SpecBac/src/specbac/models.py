from dataclasses import dataclass
from enum import Enum


class Agent(str, Enum):
    COPILOT = "copilot"
    CLAUDE = "claude"
    OPENCODE = "opencode"


class ScriptType(str, Enum):
    POWERSHELL = "ps"
    SHELL = "sh"


@dataclass(frozen=True)
class IntegrationTarget:
    root_dir: str
