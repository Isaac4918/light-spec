import json
import shutil
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path

from .integrations import INTEGRATION_TARGETS, SCRIPT_DIRECTORIES
from .models import Agent, ScriptType


@dataclass(frozen=True)
class InstallSummary:
    common_files: int
    skill_count: int
    script_count: int


def _managed_paths(project_root: Path, agent: Agent, script_type: ScriptType) -> list[Path]:
    target_root = project_root / INTEGRATION_TARGETS[agent].root_dir / "skills"
    script_dir_name = SCRIPT_DIRECTORIES[script_type]

    paths = [
        project_root / "constitution.md",
        project_root / "code_standards.md",
        project_root / "workflow_rules.md",
        target_root,
        project_root / ".specbac" / "project.json",
        project_root / ".specbac" / "scripts" / script_dir_name,
    ]
    return paths


def _validate_install_destination(project_root: Path, agent: Agent, script_type: ScriptType, force: bool) -> None:
    conflicts = [path for path in _managed_paths(project_root, agent, script_type) if path.exists()]
    if conflicts and not force:
        formatted = "\n".join(str(path) for path in conflicts)
        raise ValueError(
            "SpecBac-managed files or folders already exist at the destination. "
            "Use --force to overwrite them.\n"
            f"{formatted}"
        )


def _copy_tree(source, destination: Path) -> int:
    count = 0
    if source.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
        for child in source.iterdir():
            count += _copy_tree(child, destination / child.name)
        return count

    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(source.read_bytes())
    return 1


def _copy_skill_tree(source, destination: Path) -> int:
    count = 0
    destination.mkdir(parents=True, exist_ok=True)
    for child in source.iterdir():
        if source.name == "specbac-init-project" and child.name == "scripts":
            continue
        count += _copy_tree(child, destination / child.name)
    return count


def _write_metadata(project_root: Path, agent: Agent, script_type: ScriptType, version: str) -> None:
    metadata_path = project_root / ".specbac" / "project.json"
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(
        json.dumps(
            {
                "name": project_root.name,
                "agent": agent.value,
                "script": script_type.value,
                "specbac_version": version,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def install_project_assets(project_root: Path, agent: Agent, script_type: ScriptType, version: str, force: bool = False) -> InstallSummary:
    asset_root = files("specbac") / "assets"
    _validate_install_destination(project_root, agent, script_type, force)

    common_root = asset_root / "common"
    common_files = 0
    for item in common_root.iterdir():
        common_files += _copy_tree(item, project_root / item.name)

    target_root = project_root / INTEGRATION_TARGETS[agent].root_dir / "skills"
    skills_root = asset_root / "skills"
    skill_count = 0
    for item in skills_root.iterdir():
        skill_count += _copy_skill_tree(item, target_root / item.name)

    legacy_init_scripts = target_root / "specbac-init-project" / "scripts"
    if legacy_init_scripts.exists():
        shutil.rmtree(legacy_init_scripts)

    script_dir_name = SCRIPT_DIRECTORIES[script_type]
    script_root = asset_root / "scripts" / script_dir_name
    script_target = project_root / ".specbac" / "scripts" / script_dir_name
    script_count = 0
    for item in script_root.iterdir():
        script_count += _copy_tree(item, script_target / item.name)

    _write_metadata(project_root, agent, script_type, version)
    return InstallSummary(common_files=common_files, skill_count=skill_count, script_count=script_count)
