from pathlib import Path
from typing import Optional

import typer

from .filesystem import ensure_existing_directory, ensure_project_directory
from .installer import install_project_assets
from .models import Agent, ScriptType
from .prompts import resolve_agent, resolve_script_type
from .version import __version__

app = typer.Typer(help="SpecBac CLI")


@app.command("version")
def version() -> None:
    """Print the installed SpecBac CLI version."""
    typer.echo(__version__)


@app.command("init")
def init(
    project_name: str,
    agent: Optional[Agent] = typer.Option(None, "--agent", help="Coding agent integration."),
    script: Optional[ScriptType] = typer.Option(None, "--script", help="Script type to install."),
    path: Optional[Path] = typer.Option(None, "--path", help="Base path where the project folder will be created."),
    non_interactive: bool = typer.Option(False, "--non-interactive", help="Use defaults instead of prompting."),
    force: bool = typer.Option(False, "--force", help="Allow initialization inside an existing directory."),
) -> None:
    """Create a new SpecBac project scaffold."""
    selected_agent = resolve_agent(agent, non_interactive)
    selected_script = resolve_script_type(script, non_interactive)
    project_root = ensure_project_directory(project_name, path, force)
    summary = install_project_assets(project_root, selected_agent, selected_script, __version__, force=force)

    typer.echo(f"SpecBac project created at: {project_root}")
    typer.echo(f"Agent integration: {selected_agent.value}")
    typer.echo(f"Script type: {selected_script.value}")
    typer.echo(f"Common files copied: {summary.common_files}")
    typer.echo(f"Skills copied: {summary.skill_count}")
    typer.echo(f"Scripts copied: {summary.script_count}")


@app.command("install")
def install(
    agent: Optional[Agent] = typer.Option(None, "--agent", help="Coding agent integration."),
    script: Optional[ScriptType] = typer.Option(None, "--script", help="Script type to install."),
    path: Optional[Path] = typer.Option(None, "--path", help="Existing project path. Defaults to the current directory."),
    non_interactive: bool = typer.Option(False, "--non-interactive", help="Use defaults instead of prompting."),
    force: bool = typer.Option(False, "--force", help="Overwrite existing SpecBac-managed files and folders."),
) -> None:
    """Install SpecBac into an existing project directory."""
    selected_agent = resolve_agent(agent, non_interactive)
    selected_script = resolve_script_type(script, non_interactive)
    project_root = ensure_existing_directory(path)
    summary = install_project_assets(project_root, selected_agent, selected_script, __version__, force=force)

    typer.echo(f"SpecBac installed in: {project_root}")
    typer.echo(f"Agent integration: {selected_agent.value}")
    typer.echo(f"Script type: {selected_script.value}")
    typer.echo(f"Common files copied: {summary.common_files}")
    typer.echo(f"Skills copied: {summary.skill_count}")
    typer.echo(f"Scripts copied: {summary.script_count}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()

