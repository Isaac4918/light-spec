#!/usr/bin/env bash

set -euo pipefail

python_cmd=""

if command -v python3 >/dev/null 2>&1; then
  python_cmd="python3"
elif command -v python >/dev/null 2>&1; then
  python_cmd="python"
fi

environment_type="none"
environment_name="null"
is_active_environment="false"

if [[ -n "${CONDA_DEFAULT_ENV:-}" ]]; then
  environment_type="conda"
  environment_name="$CONDA_DEFAULT_ENV"
  is_active_environment="true"
elif [[ -n "${VIRTUAL_ENV:-}" ]]; then
  environment_type="venv"
  environment_name="$(basename "$VIRTUAL_ENV")"
  is_active_environment="true"
fi

python_version="null"
is_supported_version="false"
is_ready="false"
reason="null"

if [[ -n "$python_cmd" ]]; then
  python_version="$($python_cmd -c 'import sys; print(".".join(map(str, sys.version_info[:3])))')"
  if $python_cmd -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)'; then
    is_supported_version="true"
  fi
fi

if [[ "$is_active_environment" != "true" ]]; then
  reason="No hay un entorno conda o venv activo."
elif [[ "$python_version" == "null" ]]; then
  reason="No se pudo determinar la version de Python del entorno activo."
elif [[ "$is_supported_version" != "true" ]]; then
  reason="La version de Python activa es $python_version y se requiere 3.12 o superior."
else
  is_ready="true"
  reason="Entorno Python valido."
fi

cat <<EOF
{
  "environmentType": "$environment_type",
  "environmentName": $([[ "$environment_name" == "null" ]] && echo null || printf '"%s"' "$environment_name"),
  "pythonCommand": $([[ -z "$python_cmd" ]] && echo null || printf '"%s"' "$python_cmd"),
  "pythonVersion": $([[ "$python_version" == "null" ]] && echo null || printf '"%s"' "$python_version"),
  "isActiveEnvironment": $is_active_environment,
  "isSupportedVersion": $is_supported_version,
  "isReady": $is_ready,
  "reason": $(printf '%s' "$reason" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))' 2>/dev/null || printf '"%s"' "$reason")
}
EOF
