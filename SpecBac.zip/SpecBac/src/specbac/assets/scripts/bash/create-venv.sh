#!/usr/bin/env bash

set -euo pipefail

environment_path="${1:-.venv}"

find_uv() {
  if command -v uv >/dev/null 2>&1; then
    echo "uv"
    return 0
  fi

  return 1
}

uv_cmd="$(find_uv || true)"
if [[ -z "$uv_cmd" ]]; then
  echo "No se encontro uv en el sistema. Instala uv antes de crear el entorno virtual." >&2
  exit 1
fi

if [[ -e "$environment_path" ]]; then
  echo "La ruta '$environment_path' ya existe." >&2
  exit 1
fi

"$uv_cmd" venv "$environment_path" --python 3.12

if [[ ! -x "$environment_path/bin/python" ]]; then
  echo "No se pudo crear el entorno virtual con uv." >&2
  exit 1
fi

cat <<EOF
{
  "environmentPath": "$(cd "$environment_path" && pwd)",
  "activationCommand": "source $environment_path/bin/activate",
  "pythonCommandUsed": "$uv_cmd venv $environment_path --python 3.12",
  "status": "created"
}
EOF