param(
    [string]$EnvironmentPath = '.venv'
)

function Get-UvCommand {
    if (Get-Command uv -ErrorAction SilentlyContinue) {
        return 'uv'
    }

    return $null
}

$uvCommand = Get-UvCommand
if (-not $uvCommand) {
    throw 'No se encontro uv en el sistema. Instala uv antes de crear el entorno virtual.'
}

if (Test-Path $EnvironmentPath) {
    throw "La ruta '$EnvironmentPath' ya existe."
}

& $uvCommand venv $EnvironmentPath --python 3.12

if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $EnvironmentPath 'Scripts\python.exe'))) {
    throw 'No se pudo crear el entorno virtual con uv.'
}

[ordered]@{
    environmentPath = (Resolve-Path $EnvironmentPath).Path
    activationCommand = ".\$EnvironmentPath\Scripts\Activate.ps1"
    pythonCommandUsed = "$uvCommand venv $EnvironmentPath --python 3.12"
    status = 'created'
} | ConvertTo-Json -Depth 3