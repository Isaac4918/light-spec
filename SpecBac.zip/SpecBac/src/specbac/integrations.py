from .models import Agent, IntegrationTarget, ScriptType

INTEGRATION_TARGETS: dict[Agent, IntegrationTarget] = {
    Agent.COPILOT: IntegrationTarget(root_dir=".github"),
    Agent.CLAUDE: IntegrationTarget(root_dir=".claude"),
    Agent.OPENCODE: IntegrationTarget(root_dir=".opencode"),
}

SCRIPT_DIRECTORIES: dict[ScriptType, str] = {
    ScriptType.POWERSHELL: "powershell",
    ScriptType.SHELL: "bash",
}
