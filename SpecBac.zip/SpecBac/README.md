# SpecBac (Versión 0.1.0)

> Un flujo de trabajo para GitHub Copilot centrado en backlog, specs y memoria operativa. Convierte ideas vagas o proyectos ya existentes en trabajo verificable: explorar -> formalizar -> especificar cuando haga falta -> implementar una sola feature -> validar y sincronizar.

---

## ¿Por qué SpecBac?

Muchos flujos asistidos por IA saltan demasiado pronto a escribir código. SpecBac fuerza una disciplina distinta: primero define qué capacidad existe o falta, luego la registra en un backlog formal, exige spec solo cuando la feature lo necesita, y recién después implementa con evidencia explícita de cierre.

La idea central es simple: el trabajo no vive solo en prompts o en la memoria de la sesión. Vive en artefactos persistentes que cualquier agente puede retomar sin reinventar contexto.

**Frase corta**: SpecBac ordena el trabajo alrededor de `feature_list.json`, `specs/` y `memory/`, con estados de backlog explícitos y validación verificable antes de cerrar una feature.

---

## Instalacion

### Instalacion desde Git remoto

```bash
uv tool install --from git+https://dev.azure.com/ORG-LAT-GDA/GCGT-IAGen/_git/SpecBAC@develop specbac-cli
```

Este modo instala el CLI directamente desde la branch `develop` del repositorio remoto.

### Instalacion local desde el repositorio clonado

```bash
git clone https://dev.azure.com/ORG-LAT-GDA/GCGT-IAGen/_git/SpecBAC
cd SpecBac
git checkout develop
uv tool install .
```

Despues de eso, el comando `specbac` queda disponible en tu entorno de herramientas de `uv`.


## Actualizacion

### Si instalaste desde una copia local clonada

Trae los cambios nuevos al repositorio local y reinstala desde esa carpeta:

```bash
git pull
uv tool install . --force
```

### Si instalaste desde Git remoto con version fija

Reinstala apuntando nuevamente a la branch `develop`:

```bash
uv tool install --from git+https://dev.azure.com/ORG-LAT-GDA/GCGT-IAGen/_git/SpecBAC@develop specbac-cli --force
```

Puedes verificar la version instalada con:

```bash
specbac version
```

## Uso del CLI

Crear un proyecto nuevo:

```bash
specbac init MiProyecto
```

Instalar SpecBac en el directorio actual para un proyecto ya existente:

```bash
specbac install
```

Instalar SpecBac en un proyecto existente especificando una ruta:

```bash
specbac install --path /ruta/al/proyecto
```

Si faltan `--agent` o `--script`, el CLI preguntara interactivamente por ambas opciones.

Si el proyecto ya contiene archivos gestionados por SpecBac y quieres sobrescribirlos, usa:

```bash
specbac install --force
```

---

## El flujo

```text
/specbac-init-project -> /specbac-add-feature -> /specbac-create-spec -> /specbac-implement-feature
                           ^                        |
                           |                        v
               /specbac-explore-ideas      /specbac-validate-feature-list

/specbac-adapt-old-project -> /specbac-sync-docs

/specbac-validate-standards puede ejecutarse sobre código real en cualquier momento.
```

`/specbac-create-spec` solo aplica a features con `sdd: true`. Si una feature no requiere spec, puede pasar de `pending` a implementación directa.

| Paso | Comando | Qué hace | Produce |
|------|---------|----------|---------|
| 0 | `/specbac-init-project` | Inicializa un proyecto nuevo y confirma arquitectura, reglas y stack | Estructura base + `feature_list.json` vacío |
| A | `/specbac-adapt-old-project` | Adapta un proyecto existente al flujo | Backlog, memoria y specs derivados del código real |
| 1 | `/specbac-explore-ideas` | Aclara ideas antes de escribir backlog | Features candidatas propuestas en chat |
| 2 | `/specbac-add-feature` | Agrega, reabre, divide o corrige features | `feature_list.json` actualizado |
| 3 | `/specbac-create-spec` | Crea specs para features `pending` con `sdd: true` | `specs/<feature>/requirements.md`, `design.md`, `tasks.md` |
| 4 | `/specbac-implement-feature` | Implementa exactamente una feature | Código + tests + memoria + backlog actualizado |
| 5 | `/specbac-validate-feature-list` | Audita consistencia y prioridad del backlog | Correcciones aprobadas en `feature_list.json` |
| 6 | `/specbac-sync-docs` | Reconciliación documental contra el código real | Backlog, memoria y docs permitidas alineadas |
| 7 | `/specbac-validate-standards` | Revisión del código contra constitution y standards | Hallazgos y recomendaciones, sin editar código |

---

## Comandos

| Comando | Uso principal |
|---------|---------------|
| `specbac init <ProjectName>` | Crea una carpeta nueva e instala SpecBac dentro de ella |
| `specbac install` | Instala SpecBac en un proyecto existente |
| `specbac version` | Muestra la version instalada del CLI |
| `/specbac-init-project` | Inicializa un proyecto nuevo y crea el backlog base |
| `/specbac-adapt-old-project` | Formaliza un proyecto existente dentro del flujo |
| `/specbac-explore-ideas` | Aclara ideas antes de escribir backlog |
| `/specbac-add-feature` | Agrega, reabre, divide o corrige features |
| `/specbac-create-spec` | Crea specs para features con `sdd: true` |
| `/specbac-implement-feature` | Implementa exactamente una feature |
| `/specbac-sync-docs` | Alinea backlog, specs y memoria con el código real |
| `/specbac-validate-feature-list` | Audita consistencia y prioridad del backlog |
| `/specbac-validate-standards` | Revisa el código contra constitution y standards |

---

## Artefactos

| Artefacto | Rol en el flujo |
|-----------|-----------------|
| `feature_list.json` | Backlog formal y fuente de verdad del estado de cada feature |
| `memory/current.md` | Contexto operativo de la feature en curso |
| `memory/history.md` | Historial acumulado de trabajo y validaciones |
| `memory/<feature>.md` | Memoria específica por feature cuando aplica |
| `specs/<feature>/requirements.md` | Requisitos verificables |
| `specs/<feature>/design.md` | Diseño propuesto y alternativas rechazadas |
| `specs/<feature>/tasks.md` | Checklist ejecutable con validación esperada |
| `constitution.md` | Principios no negociables del proyecto |
| `code_standards.md` | Reglas de estructura, nombres, testing, seguridad y observabilidad |
| `workflow_rules.md` | Reglas compartidas del flujo y modelo de estados |

---

## Reglas clave del modelo de trabajo

- Como máximo puede existir una feature `in_progress` a la vez.
- Una feature con `sdd: true` debe pasar por `spec_ready` antes de implementación.
- Una feature bloqueada mantiene su estado principal y registra el bloqueo como metadata.
- Reabrir una feature `done` la devuelve a `pending`; no recupera `spec_ready` automáticamente.
- El cierre requiere validación explícita, no solo código escrito.
- Las decisiones que afecten arquitectura, costo, seguridad, datos u operaciones requieren aprobación humana.
