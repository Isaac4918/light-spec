# Reto 3 - Paso a paso desde cero en Azure personal

## Objetivo

Construir un data pipeline en Azure Data Factory, partiendo de una suscripción personal de Azure, para consumir la API de Open Library y guardar la respuesta en el Data Lake en el formato más adecuado según la estructura real de los datos.

## Supuesto de esta guía

Esta guía asume que:

1. Vas a trabajar en tu propia cuenta de Azure.
2. No tienes nada creado todavía para este reto.
3. Necesitas preparar desde cero el storage, el Data Factory y el pipeline.
4. El API es público y se consumirá mediante `GET`.

## Qué pide exactamente el reto

Debes cumplir estas reglas:

1. Consumir la URL indicada en el documento original usando `GET`.
2. Analizar la estructura devuelta por la API.
3. Decidir si guardar el resultado en `.json` o `.parquet`.
4. Explicar en la defensa por qué tomaste esa decisión.
5. Guardar el archivo en una ruta como esta:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Api/OpenLibrary/Search/Search.[parquet o json]
```

## Recomendación técnica para este reto

La opción más defendible normalmente es guardar el resultado como `.json`.

La razón es esta:

1. La respuesta de Open Library suele traer estructuras anidadas.
2. El request del reto pide campos como `author_name`, `editions`, `editions.key`, `editions.title`, `editions.ebook_access` y `editions.language`.
3. Eso introduce arrays y objetos anidados que en JSON se preservan de forma natural.
4. Si quisieras parquet, tendrías que aplanar o transformar la respuesta, lo cual ya no sería una copia directa tan limpia para este reto.

## Arquitectura mínima que vas a crear

Para resolver este reto en una cuenta personal nueva, necesitas crear como mínimo:

1. Una suscripción de Azure activa.
2. Un Resource Group.
3. Una Storage Account con `Hierarchical namespace` habilitado.
4. Un File System o contenedor para usarlo como Data Lake.
5. Un Azure Data Factory.
6. Un linked service HTTP o REST.
7. Un linked service al Data Lake.
8. Un dataset REST o HTTP de origen.
9. Un dataset JSON de destino.
10. Un pipeline con una actividad `Copy Data`.

## Resultado esperado

Al ejecutar el pipeline:

1. Azure Data Factory llama a la API con `GET`.
2. Recibe la respuesta.
3. Guarda el resultado en tu Data Lake.
4. El archivo final queda en la ruta pedida por el reto.

## Fase 1. Preparar la cuenta personal de Azure

## Paso 1. Verificar que tu cuenta de Azure esté lista

Antes de crear recursos, confirma esto:

1. Tienes una cuenta de Azure activa.
2. Tu suscripción permite crear recursos.
3. Puedes entrar al portal en `https://portal.azure.com`.

## Paso 2. Elegir una región

Escoge una sola región para mantener simple el laboratorio y reducir costos.

## Paso 3. Crear un Resource Group

En Azure Portal:

1. Busca `Resource groups`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción.
4. Asigna un nombre claro.
5. Elige la región.
6. Crea el recurso.

## Fase 2. Crear el Data Lake desde cero

## Paso 4. Crear la Storage Account

En Azure Portal:

1. Busca `Storage accounts`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción y el Resource Group recién creado.
4. Elige un nombre único global.
5. Región: usa la misma del Resource Group.
6. Performance: `Standard`.
7. Redundancy: `LRS`.
8. Activa `Hierarchical namespace`.

## Paso 5. Crear el File System del Data Lake

Cuando la Storage Account ya exista:

1. Entra al recurso.
2. Ve a `Containers` o `Storage browser`.
3. Crea un File System o contenedor.

Ejemplo:

```text
data
```

## Fase 3. Crear Azure Data Factory

## Paso 6. Crear el recurso Azure Data Factory

En Azure Portal:

1. Busca `Data Factories`.
2. Haz clic en `Create`.
3. Usa la misma suscripción y el mismo Resource Group.
4. Pon un nombre único.
5. Región: usa la misma del Storage.
6. En `Git configuration`, puedes dejar `Configure Git later`.
7. Crea el recurso.

## Paso 7. Abrir ADF Studio

Cuando termine la creación:

1. Entra al recurso.
2. Haz clic en `Launch studio`.

## Fase 4. Preparar conexiones

## Paso 8. Crear el linked service a la API

En ADF Studio:

1. Ve a `Manage`.
2. Entra a `Linked services`.
3. Crea uno nuevo.
4. Selecciona `REST` o `HTTP`, según el conector disponible que mejor se adapte.
5. Configura la URL base de Open Library.
6. Como el API es público, normalmente no necesitarás autenticación compleja.
7. Prueba la conexión.
8. Guarda.

Sugerencia de nombre:

```text
LS_REST_OpenLibrary
```

## Paso 9. Crear el linked service al Data Lake personal

1. En `Manage`, crea otro linked service.
2. Selecciona `Azure Data Lake Storage Gen2`.
3. Elige tu Storage Account personal.
4. Usa el método de autenticación más simple disponible en ADF.
5. Prueba la conexión.
6. Guarda.

Sugerencia de nombre:

```text
LS_ADLS_BLL_PERSONAL
```

## Fase 5. Crear datasets

## Paso 10. Crear el dataset de origen para la API

1. Ve a `Author`.
2. Crea un dataset nuevo de tipo `REST` o `HTTP`.
3. Asócialo al linked service `LS_REST_OpenLibrary`.
4. Configura la ruta relativa o URL completa según el conector.
5. Usa el método `GET`.
6. Guarda.

Sugerencia de nombre:

```text
DS_REST_OpenLibrary_Search
```

## Paso 11. Configurar la URL exacta del reto

Debes consumir la URL indicada por el documento original del laboratorio. Si la partes entre base URL y relative URL, asegúrate de que el resultado final sea exactamente el endpoint pedido por el reto.

## Paso 12. Revisar la respuesta del API

Antes de definir el destino:

1. Usa `Preview data` o prueba equivalente si el conector lo permite.
2. Confirma que la respuesta trae estructuras anidadas.
3. Identifica si el payload tiene arrays, objetos y subcampos.

Ese análisis es el que vas a usar para justificar el formato final.

## Paso 13. Crear el dataset JSON de destino

Como recomendación técnica, usa JSON como formato final.

1. Crea un dataset nuevo de tipo `Azure Data Lake Storage Gen2`.
2. Selecciona formato `JSON`.
3. Usa el linked service `LS_ADLS_BLL_PERSONAL`.
4. Selecciona el File System que creaste.
5. Guarda.

Sugerencia de nombre:

```text
DS_ADLS_OpenLibrary_JSON
```

## Fase 6. Crear el pipeline del reto

## Paso 14. Crear el pipeline

1. Crea un pipeline nuevo.
2. Ponle un nombre claro.

Ejemplo:

```text
PL_API_OpenLibrary_To_JSON
```

## Paso 15. Agregar la actividad `Copy Data`

1. Arrastra una actividad `Copy data` al canvas.
2. Nómbrala:

```text
CPY_OpenLibrary_To_JSON
```

## Paso 16. Configurar el source

En la pestaña `Source`:

1. Selecciona el dataset `DS_REST_OpenLibrary_Search`.
2. Confirma que el método sea `GET`.
3. Verifica que la URL final coincida con el reto.

## Paso 17. Configurar el sink

En la pestaña `Sink`:

1. Selecciona `DS_ADLS_OpenLibrary_JSON`.
2. Define el File System correcto.
3. Configura el `folder path` como:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Api/OpenLibrary/Search
```

4. Configura el `file name` como:

```text
Search.json
```

## Paso 18. Si insistes en parquet

Solo usa parquet si primero transformas y aplanas la respuesta.

Eso implicaría:

1. Identificar cuál parte del JSON vas a guardar.
2. Aplanar arrays y objetos.
3. Definir un esquema tabular consistente.

Eso es más trabajo y requiere justificar por qué no preservaste la estructura original. Para este reto, JSON suele ser una decisión más sólida.

## Fase 7. Ejecutar y validar

## Paso 19. Validar el pipeline

1. Haz `Validate`.
2. Corrige cualquier error de URL, dataset o configuración de sink.
3. Publica los cambios si ADF te lo requiere.

## Paso 20. Ejecutar en `Debug`

1. Ejecuta el pipeline en `Debug`.
2. Verifica que la llamada al API funcione.
3. Revisa que el archivo JSON se escriba sin errores.

## Paso 21. Revisar el archivo en tu Data Lake personal

Después del `Debug`, valida esto:

1. Existe la ruta esperada.
2. El archivo se llama `Search.json`.
3. El archivo quedó dentro de tu File System.
4. La estructura JSON se preserva.

## Cómo defender la decisión JSON

Puedes explicarlo así:

1. El API devuelve información semiestructurada.
2. Hay arrays y estructuras anidadas.
3. JSON preserva fielmente el payload original.
4. Parquet requeriría una transformación adicional que cambia el carácter de la ingesta.

## Riesgos comunes en cuenta personal

### 1. URL mal configurada

Si separas mal la base URL y el path, el request fallará o no traerá lo esperado.

### 2. Elegir parquet sin transformación previa

Eso puede romper el esquema o producir una salida inconsistente.

### 3. Ruta final incorrecta

El reto exige una ubicación precisa dentro del Data Lake.

## Cómo explicarlo en la defensa

En el video conviene mostrarlo así:

1. La creación del Storage Account y del Data Factory.
2. El linked service a la API.
3. La prueba de la respuesta del endpoint.
4. La decisión de usar JSON.
5. La actividad `Copy Data`.
6. La ejecución exitosa.
7. La validación del archivo en el Data Lake.

## Checklist final para ambiente personal nuevo

- Suscripción personal activa.
- Resource Group creado.
- Storage Account creada.
- `Hierarchical namespace` habilitado.
- File System creado.
- Azure Data Factory creado.
- Linked service a la API creado.
- Linked service a ADLS creado.
- Dataset de origen REST o HTTP creado.
- Dataset JSON de destino creado.
- `Copy Data` configurado.
- Ruta correcta.
- Archivo `Search.json` creado.
- Pipeline validado y ejecutado con éxito.