# Marco teórico para resolver los retos

## Objetivo de este documento

Este documento resume los conceptos más importantes de ingeniería de datos que una persona novata necesita entender para poder resolver los retos del BLL Nivel 1.

La idea no es convertirte en experto de inmediato, sino darte una base clara para entender qué estás construyendo, por qué lo haces y qué papel cumple cada componente.

## 1. ¿Qué es la ingeniería de datos?

La ingeniería de datos es la disciplina que se encarga de mover, transformar, organizar y dejar disponibles los datos para que otras personas o sistemas puedan usarlos.

En términos simples:

1. Los datos nacen en alguna fuente.
2. Deben extraerse correctamente.
3. Deben guardarse en un lugar ordenado.
4. Deben quedar listos para análisis, reportes o consumo posterior.

En estos retos, tu trabajo como principiante en ingeniería de datos es justamente ese: leer datos desde distintas fuentes y dejarlos correctamente almacenados en un Data Lake.

## 2. ¿Qué es un pipeline de datos?

Un pipeline de datos es una secuencia de pasos automatizados que mueve datos desde un origen hasta un destino.

Un pipeline normalmente hace una o varias de estas cosas:

1. Conectarse a una fuente.
2. Leer datos.
3. Filtrar o transformar datos.
4. Guardar datos en otro sistema.
5. Registrar si la ejecución fue exitosa o falló.

En los retos del BLL, cada reto consiste en construir un pipeline.

## 3. ¿Qué es la ingesta de datos?

La ingesta de datos es el proceso de traer datos desde una fuente hacia un sistema de almacenamiento o procesamiento.

Ejemplos de ingesta en estos retos:

1. Desde SQL Server hacia Data Lake.
2. Desde SFTP hacia Data Lake.
3. Desde una API hacia Data Lake.
4. Desde DB2 hacia Data Lake.

Cuando el reto dice “ingestar”, básicamente te está pidiendo leer datos desde una fuente y guardarlos en otra parte de forma controlada.

## 4. ¿Qué es una fuente de datos?

La fuente de datos es el lugar donde los datos existen originalmente.

En estos retos hay varias clases de fuentes:

1. Base de datos relacional SQL Server.
2. Servidor SFTP con archivos.
3. API web.
4. Base de datos IBM DB2.

Cada fuente tiene una forma distinta de conexión y lectura, pero todas cumplen el mismo papel: entregar la información que vas a mover.

## 5. ¿Qué es un destino de datos?

El destino es el lugar donde guardarás los datos después de extraerlos.

En estos retos, el destino principal es un Data Lake en Azure.

Eso significa que, aunque las fuentes cambian, el punto de llegada casi siempre es el mismo: archivos almacenados en el Data Lake.

## 6. ¿Qué es Azure?

Azure es la nube de Microsoft. Allí puedes crear recursos tecnológicos sin tener que instalar servidores físicos.

Para estos retos, Azure te sirve para crear el ambiente donde correrán tus pipelines y donde almacenarás los resultados.

## 7. Conceptos básicos de Azure que necesitas

### Suscripción

La suscripción es la cuenta de facturación y administración donde viven tus recursos de Azure.

### Resource Group

Un Resource Group es una carpeta lógica donde agrupas recursos relacionados.

### Recurso

Un recurso es un servicio creado dentro de Azure, por ejemplo:

1. Un Azure Data Factory.
2. Una Storage Account.

Para estos retos, lo normal es que pongas todo dentro de un mismo Resource Group.

## 8. ¿Qué es Azure Data Factory?

Azure Data Factory, o ADF, es un servicio de Azure diseñado para construir y ejecutar pipelines de datos.

Piensa en ADF como la herramienta principal con la que orquestas el trabajo.

Con ADF puedes:

1. Conectarte a fuentes.
2. Configurar datasets.
3. Diseñar pipelines.
4. Ejecutarlos.
5. Revisar errores y resultados.

En estos retos, ADF es el corazón de la solución.

## 9. Conceptos básicos dentro de Azure Data Factory

### Linked Service

Un linked service es la conexión que le dice a ADF cómo llegar a una fuente o a un destino.

Ejemplos:

1. Un linked service a SQL Server.
2. Un linked service a SFTP.
3. Un linked service a un API.
4. Un linked service a Azure Data Lake.

Sin linked services, ADF no sabe cómo conectarse a nada.

### Dataset

Un dataset representa el dato que quieres leer o escribir.

Un dataset no siempre es toda la base de datos o todo el storage. Más bien representa una tabla, un archivo o una estructura específica.

Ejemplos:

1. La tabla `dbo.Parametros`.
2. La tabla `sales.order_items`.
3. El archivo `Global_Superstore2.csv`.
4. El archivo parquet o JSON de salida.

### Pipeline

El pipeline es el flujo completo de actividades.

### Activity

Una activity es un paso dentro del pipeline.

En estos retos, las actividades más importantes son:

1. `Lookup`, para leer un valor pequeño, como una fecha.
2. `Copy Data`, para copiar datos de una fuente a un destino.

### Debug

`Debug` sirve para ejecutar el pipeline y probarlo antes de darlo por terminado.

## 10. ¿Qué es un Data Lake?

Un Data Lake es un sistema de almacenamiento pensado para guardar grandes cantidades de datos en distintos formatos.

A diferencia de una base de datos tradicional, un Data Lake puede almacenar archivos como:

1. CSV.
2. JSON.
3. Parquet.

En estos retos, el Data Lake es donde vas a dejar los resultados finales.

## 11. ¿Qué es Azure Data Lake Storage Gen2?

Azure Data Lake Storage Gen2 es una forma de almacenamiento en Azure que combina las capacidades de blobs con una estructura tipo sistema de archivos.

Eso permite trabajar con carpetas, rutas y archivos de forma ordenada.

Para estos retos, necesitas entender principalmente tres cosas:

1. Debes crear una Storage Account.
2. Debes activar `Hierarchical namespace`.
3. Debes definir bien la ruta donde quedarán los archivos.

## 12. ¿Qué es un File System o contenedor?

Dentro del Data Lake, necesitas un espacio lógico donde guardar archivos.

Ese espacio suele llamarse contenedor o file system, según el contexto.

Es como la raíz de la estructura de carpetas donde van a vivir tus resultados.

## 13. ¿Qué es una ruta de almacenamiento?

La ruta es la ubicación exacta donde se guarda un archivo dentro del Data Lake.

Ejemplo:

```text
bllengineer/Nivel1/Nombre_Apellido/Sql/Sales/Order_Items/2026/order_items_20260703.parquet
```

Saber construir bien una ruta es importante porque el reto exige una convención exacta.

## 14. Formatos de archivo que necesitas conocer

## CSV

CSV es un formato de texto donde los datos vienen separados por comas.

Ventajas:

1. Es fácil de leer.
2. Es muy común.

Desventajas:

1. No maneja bien estructuras complejas.
2. No siempre conserva tipos de datos con precisión.

## JSON

JSON es un formato ideal para datos semiestructurados, especialmente cuando hay objetos o listas anidadas.

Ventajas:

1. Preserva estructuras complejas.
2. Es muy común en APIs.

Desventajas:

1. Puede ocupar más espacio.
2. No siempre es el mejor formato para análisis tabular directo.

## Parquet

Parquet es un formato columnar muy usado en ingeniería de datos.

Ventajas:

1. Es eficiente para almacenamiento.
2. Es eficiente para lectura analítica.
3. Conserva mejor los tipos de datos que un CSV.

Desventajas:

1. No es cómodo para leer manualmente como texto.
2. No es ideal si la información viene muy anidada y no ha sido aplanada.

## 15. Datos estructurados vs semiestructurados

### Datos estructurados

Son datos organizados en tablas con filas y columnas.

Ejemplos:

1. SQL Server.
2. IBM DB2.

### Datos semiestructurados

Son datos que no siguen estrictamente una tabla simple, pero sí tienen una estructura interna.

Ejemplo:

1. JSON devuelto por una API.

Esto es importante porque te ayuda a decidir si conviene guardar algo como JSON o como parquet.

## 16. Bases de datos relacionales

Una base de datos relacional organiza la información en tablas.

Conceptos básicos que debes conocer:

1. Tabla: conjunto de datos, como `sales.order_items`.
2. Fila: un registro.
3. Columna: un atributo del registro.
4. Clave primaria: identificador principal de una fila.
5. Clave foránea: columna que relaciona una tabla con otra.

## 17. ¿Qué es un JOIN?

Un `JOIN` une información de dos tablas relacionadas.

Esto es importante en el Reto 1 porque `order_items` es el detalle y la fecha puede estar en `orders`.

Si la fecha no está en `order_items`, debes unir ambas tablas por una clave común, por ejemplo `order_id`.

## 18. ¿Qué es filtrar datos?

Filtrar significa seleccionar solo una parte de la información.

Ejemplo del Reto 1:

1. No quieres todos los registros.
2. Solo quieres los que correspondan al año y mes de la `FechaProceso`.

Filtrar bien evita mover datos innecesarios y cumple con la lógica del reto.

## 19. ¿Qué es una fecha de proceso?

La fecha de proceso es la fecha que el pipeline toma como referencia para decidir qué datos mover.

En el Reto 1, esa fecha no debe escribirse manualmente. Debe leerse desde una tabla de parámetros.

Esto introduce un concepto muy importante en ingeniería de datos: parametrización.

## 20. ¿Qué es parametrización?

Parametrizar significa no dejar valores fijos cuando esos valores deberían variar.

Ejemplos:

1. No poner la fecha escrita a mano.
2. Generar carpetas y nombres de archivos de forma dinámica.

La parametrización hace que un pipeline sea más reutilizable y más profesional.

## 21. ¿Qué es contenido dinámico en ADF?

El contenido dinámico en ADF permite construir valores en tiempo de ejecución.

Se usa para cosas como:

1. Crear carpetas con el año.
2. Crear nombres de archivo con la fecha.
3. Construir queries dinámicos.

Sin esto, tendrías que cambiar manualmente el pipeline cada vez que lo ejecutes.

## 22. ¿Qué es SFTP?

SFTP es un protocolo seguro para transferir archivos.

En el Reto 2, el archivo CSV vive en un servidor SFTP. Tu pipeline debe conectarse, leer el archivo y copiarlo al Data Lake.

Aquí lo importante es entender que no estás leyendo una tabla, sino un archivo remoto.

## 23. ¿Qué es una API?

Una API es una forma de obtener información desde un sistema usando peticiones por red.

En el Reto 3, el origen no es una tabla ni un archivo, sino una URL que devuelve datos.

## 24. ¿Qué es un endpoint?

Un endpoint es la dirección exacta a la que haces la petición.

En el caso del Reto 3, el endpoint incluye una búsqueda específica en Open Library.

## 25. ¿Qué significa método GET?

`GET` es el tipo de petición usado para consultar información.

En otras palabras, le dices al servidor: “dame estos datos”.

## 26. ¿Qué es IBM DB2?

IBM DB2 es otro motor de base de datos relacional, parecido en concepto a SQL Server, aunque con conectores y configuraciones diferentes.

En el Reto 4, la lógica general sigue siendo la misma:

1. Conectarte.
2. Leer una tabla.
3. Guardar el resultado en parquet.

## 27. ¿Qué es el esquema de datos?

El esquema describe la estructura de los datos.

Incluye cosas como:

1. Nombres de columnas.
2. Tipos de datos.
3. Orden o forma esperada de la información.

Cuando copias datos, es importante que el esquema tenga sentido tanto en el origen como en el destino.

## 28. ¿Qué son los tipos de datos?

Los tipos de datos indican qué clase de valor guarda una columna.

Ejemplos:

1. Texto.
2. Número entero.
3. Decimal.
4. Fecha.
5. Booleano.

Esto es importante porque los errores de conversión de tipos son comunes en pipelines.

## 29. ¿Qué es mapeo?

El mapeo es la relación entre columnas del origen y columnas del destino.

En muchos casos ADF puede inferirlo, pero igual debes revisarlo para asegurarte de que los datos quedan donde deben.

## 30. ¿Qué es calidad de datos?

Calidad de datos significa que la información sea correcta, consistente y útil.

En estos retos, una validación básica de calidad consiste en revisar:

1. Que el archivo se generó.
2. Que tiene datos.
3. Que las columnas tienen sentido.
4. Que el filtro aplicado fue el correcto.

## 31. ¿Qué es validación?

Validar significa comprobar que lo construido funciona como debería.

En estos retos debes validar al menos:

1. Que la conexión funciona.
2. Que el pipeline ejecuta sin error.
3. Que el archivo final existe.
4. Que el contenido coincide con lo esperado.

## 32. ¿Qué es debugging?

Debugging es el proceso de ejecutar, revisar errores y corregir problemas.

En ADF, el botón `Debug` te permite probar el pipeline antes de darlo por finalizado.

## 33. ¿Qué es monitoreo?

Monitoreo es revisar cómo se ejecutan los pipelines, si fallan y por qué.

Aunque en estos retos el monitoreo no es el tema principal, sí debes observar:

1. Si una actividad falló.
2. En cuál paso falló.
3. Qué mensaje de error devolvió.

## 34. ¿Qué es conectividad?

Conectividad significa que tu pipeline realmente puede alcanzar la fuente o el destino por red.

Un pipeline puede estar perfectamente diseñado y aun así fallar si:

1. El servidor no responde.
2. El puerto está mal.
3. Las credenciales son incorrectas.
4. La red bloquea el acceso.

## 35. ¿Qué es autenticación?

Autenticación es la forma en que demuestras quién eres ante un sistema.

Ejemplos en estos retos:

1. Usuario y contraseña para SQL Server.
2. Usuario y contraseña para SFTP.
3. Credenciales de DB2.
4. Acceso al Data Lake desde Azure.

## 36. ¿Qué es transformación de datos?

Transformar datos significa cambiar su estructura, contenido o formato.

En estos retos, la transformación es mínima, pero sí existe en casos como:

1. Convertir CSV a parquet.
2. Filtrar por fecha.
3. Elegir JSON en vez de parquet cuando hay estructuras anidadas.

## 37. Batch processing

Batch processing significa procesar datos por lotes, no en tiempo real.

Estos retos son de tipo batch porque:

1. Tomas una fuente.
2. Ejecutas un pipeline.
3. Generas un archivo final.

No estás procesando eventos en vivo segundo a segundo.

## 38. ¿Por qué importa la convención de nombres?

Los retos insisten en rutas y nombres específicos porque en ingeniería de datos el orden importa.

Una buena convención permite:

1. Encontrar archivos fácilmente.
2. Entender qué contiene cada carpeta.
3. Automatizar procesos futuros.

## 39. Costos en la nube

Cuando trabajas en Azure personal, cada recurso puede generar costo.

Por eso conviene:

1. Crear solo lo necesario.
2. Usar configuraciones básicas.
3. Eliminar recursos cuando ya no los necesites.

## 40. Qué debería entender una persona novata al final

Después de estudiar estos conceptos, una persona novata debería poder entender esto:

1. Un pipeline mueve datos de una fuente a un destino.
2. Azure Data Factory es la herramienta con la que diseñas ese flujo.
3. Azure Data Lake es el lugar donde guardarás los archivos.
4. Cada fuente de datos requiere su propia conexión.
5. Debes escoger bien el formato de salida.
6. Debes validar que el resultado final sea correcto.

## Resumen final

Para resolver estos retos no necesitas dominar toda la ingeniería de datos, pero sí entender bien estas ideas:

1. Qué es un pipeline.
2. Qué es una fuente y un destino.
3. Cómo funciona Azure Data Factory.
4. Qué es un Data Lake.
5. Diferencia entre CSV, JSON y parquet.
6. Qué es filtrar, parametrizar y usar rutas dinámicas.
7. Cómo validar que la ingesta salió bien.

Con esa base ya puedes seguir los archivos prácticos del workspace y construir los retos con mucho más sentido.