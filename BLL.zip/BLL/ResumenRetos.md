# Resumen básico de los retos

## Objetivo de este archivo

Esta guía es una versión corta de lo mínimo que necesitas para hacer los retos en una cuenta personal de Azure, sin reemplazar los archivos detallados.

## Lo mínimo que debes tener antes de cualquier reto

1. Una suscripción de Azure activa.
2. Un `Resource Group`.
3. Una `Storage Account` con `Hierarchical namespace` activado.
4. Un `File System` o contenedor en el Data Lake.
5. Un `Azure Data Factory`.
6. Un linked service al Data Lake.
7. Acceso a las credenciales de la fuente del reto que vas a hacer.

## Recursos base recomendados

Puedes usar algo así:

```text
Resource Group: rg-bll-personal
Storage Account: stbllpersonal001
File System: data
Data Factory: adf-bll-personal-001
```

## Reto 1: SQL Server a parquet

### Qué necesitas

1. Linked service a SQL Server.
2. Dataset para `dbo.Parametros`.
3. Dataset para `sales.order_items`.
4. Dataset parquet en ADLS.
5. Pipeline con `Lookup` y `Copy Data`.

### Lógica básica

1. Leer `FechaProceso` desde `BikeStores.dbo.Parametros`.
2. Filtrar `order_items` por el año y mes de esa fecha.
3. Si `order_date` no existe en `order_items`, unir con `sales.orders`.
4. Guardar el resultado en parquet.

### Ruta final

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sql/Sales/Order_Items/<YYYY>/order_items_<YYYYMMDD>.parquet
```

## Reto 2: SFTP CSV a parquet

### Qué necesitas

1. Linked service a SFTP.
2. Dataset CSV de origen.
3. Dataset parquet en ADLS.
4. Pipeline con `Copy Data`.

### Lógica básica

1. Leer `Global_Superstore2.csv` desde SFTP.
2. Confirmar delimitador y encabezados.
3. Copiar a parquet en el Data Lake.

### Ruta final

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sftp/Global/Superstore/superstore2.parquet
```

## Reto 3: API a JSON o parquet

### Qué necesitas

1. Linked service HTTP o REST.
2. Dataset de origen para la API.
3. Dataset de salida en ADLS.
4. Pipeline con `Copy Data`.

### Lógica básica

1. Consumir la URL pedida usando `GET`.
2. Revisar la estructura de la respuesta.
3. Elegir el formato final.

### Recomendación corta

Lo más seguro normalmente es usar `JSON`, porque la respuesta trae datos anidados y arrays.

### Ruta final

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Api/OpenLibrary/Search/Search.json
```

## Reto 4 opcional: DB2 a parquet

### Qué necesitas

1. Linked service a IBM DB2.
2. Dataset DB2 de origen.
3. Dataset parquet en ADLS.
4. Pipeline con `Copy Data`.

### Lógica básica

1. Leer `CHINOOK.INVOICE`.
2. Copiar el resultado a parquet.

### Ruta final

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Db2/Chinook/Invoice/invoice.parquet
```

## Orden recomendado para trabajar

1. Crear Storage Account con Data Lake Gen2.
2. Crear File System.
3. Crear Azure Data Factory.
4. Crear linked service al Data Lake.
5. Crear linked service a la fuente del reto.
6. Crear datasets.
7. Crear pipeline.
8. Validar.
9. Ejecutar en `Debug`.
10. Revisar el archivo final en el Data Lake.

## Errores más comunes

1. No activar `Hierarchical namespace`.
2. Configurar mal las credenciales de la fuente.
3. Usar una ruta final distinta a la pedida.
4. No validar la estructura del archivo o respuesta antes de copiar.
5. En Reto 1, asumir que `order_date` está en `order_items`.

## Qué mostrar en la defensa

1. Los recursos creados en Azure.
2. Los linked services.
3. Los datasets.
4. El pipeline.
5. La ejecución exitosa.
6. El archivo final en el Data Lake.

## Archivos detallados

Si necesitas el paso a paso completo, revisa estos archivos:

1. `Reto1.md`
2. `Reto2.md`
3. `Reto3.md`
4. `Reto4.md`