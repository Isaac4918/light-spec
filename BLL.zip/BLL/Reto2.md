# Reto 2 - Paso a paso desde cero en Azure personal

## Objetivo

Construir un data pipeline en Azure Data Factory, partiendo de una suscripción personal de Azure, para leer el archivo `Global_Superstore2.csv` desde un servidor SFTP y guardarlo como `.parquet` en tu Data Lake.

## Supuesto de esta guía

Esta guía asume que:

1. Vas a trabajar en tu propia cuenta de Azure.
2. No tienes nada creado todavía para este reto.
3. Necesitas preparar desde cero el storage, el Data Factory y el pipeline.
4. Ya cuentas con las credenciales del SFTP que vienen en el documento original del laboratorio.

## Qué pide exactamente el reto

Debes cumplir estas reglas:

1. Leer el archivo `Global_Superstore2.csv` desde el servidor SFTP.
2. Guardar los datos en formato `.parquet`.
3. El archivo final debe quedar en esta ruta:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sftp/Global/Superstore/superstore2.parquet
```

## Arquitectura mínima que vas a crear

Para resolver este reto en una cuenta personal nueva, necesitas crear como mínimo:

1. Una suscripción de Azure activa.
2. Un Resource Group.
3. Una Storage Account con `Hierarchical namespace` habilitado.
4. Un File System o contenedor para usarlo como Data Lake.
5. Un Azure Data Factory.
6. Un linked service al servidor SFTP.
7. Un linked service al Data Lake.
8. Un dataset CSV de origen.
9. Un dataset parquet de destino.
10. Un pipeline con una actividad `Copy Data`.

## Resultado esperado

Al ejecutar el pipeline:

1. Azure Data Factory se conecta al SFTP.
2. Lee el archivo `Global_Superstore2.csv`.
3. Convierte el contenido a parquet.
4. Lo escribe en la ruta pedida por el reto.

## Fase 1. Preparar la cuenta personal de Azure

## Paso 1. Verificar que tu cuenta de Azure esté lista

Antes de crear recursos, confirma esto:

1. Tienes una cuenta de Azure activa.
2. Tu suscripción permite crear recursos.
3. Puedes entrar al portal en `https://portal.azure.com`.

## Paso 2. Elegir una región

Escoge una sola región para mantener simple el laboratorio y reducir costos.

Recomendación práctica:

1. Usa una región común como `East US` o `South Central US`.
2. Crea tanto el Storage como el Data Factory en la misma región.

## Paso 3. Crear un Resource Group

En Azure Portal:

1. Busca `Resource groups`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción.
4. Asigna un nombre claro.

Ejemplo:

```text
rg-bll-personal
```

5. Elige la región.
6. Crea el recurso.

## Fase 2. Crear el Data Lake desde cero

## Paso 4. Crear la Storage Account

En Azure Portal:

1. Busca `Storage accounts`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción y el Resource Group recién creado.
4. Elige un nombre único global.
5. Región: usa la misma del Resource Group.
6. Performance: `Standard`.
7. Redundancy: `LRS` para mantener bajo el costo.

## Paso 5. Habilitar Data Lake Gen2

Durante la creación de la Storage Account, asegúrate de activar:

```text
Hierarchical namespace
```

## Paso 6. Crear el File System del Data Lake

Cuando la Storage Account ya exista:

1. Entra al recurso.
2. Ve a `Containers` o `Storage browser`.
3. Crea un File System o contenedor.

Ejemplo:

```text
data
```

## Paso 7. Definir la ruta base del laboratorio

La ruta final del reto debe verse así:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sftp/Global/Superstore/superstore2.parquet
```

No necesitas crear manualmente todas las carpetas si ADF las va a generar, pero sí debes tener claro tu nombre exacto en la ruta.

## Fase 3. Crear Azure Data Factory

## Paso 8. Crear el recurso Azure Data Factory

En Azure Portal:

1. Busca `Data Factories`.
2. Haz clic en `Create`.
3. Usa la misma suscripción y el mismo Resource Group.
4. Pon un nombre único.
5. Región: usa la misma del Storage.
6. En `Git configuration`, puedes dejar `Configure Git later`.
7. Crea el recurso.

## Paso 9. Abrir ADF Studio

Cuando termine la creación:

1. Entra al recurso.
2. Haz clic en `Launch studio`.

## Fase 4. Preparar conexiones

## Paso 10. Confirmar qué necesitas para conectar al SFTP

Para el Reto 2 necesitas conectarte al servidor SFTP descrito en la guía original.

Debes tener:

1. Host.
2. Puerto.
3. Usuario.
4. Contraseña.
5. Nombre del archivo `Global_Superstore2.csv`.

## Paso 11. Crear el linked service al SFTP

En ADF Studio:

1. Ve a `Manage`.
2. Entra a `Linked services`.
3. Crea uno nuevo.
4. Selecciona `SFTP`.
5. Configura host, puerto, usuario y contraseña del documento original.
6. Prueba la conexión.
7. Guarda.

Sugerencia de nombre:

```text
LS_SFTP_GlobalSuperstore
```

## Paso 12. Crear el linked service al Data Lake personal

1. En `Manage`, crea otro linked service.
2. Selecciona `Azure Data Lake Storage Gen2`.
3. Elige tu Storage Account personal.
4. Usa el método de autenticación más simple disponible en ADF.
5. Prueba la conexión.
6. Guarda.

Sugerencia de nombre:

```text
LS_ADLS_BLL_PERSONAL
```

## Fase 5. Crear datasets

## Paso 13. Crear el dataset CSV de origen

1. Ve a `Author`.
2. Crea un dataset nuevo de tipo `DelimitedText`.
3. Asígnalo al linked service `LS_SFTP_GlobalSuperstore`.
4. Selecciona el archivo `Global_Superstore2.csv`.
5. Indica que el delimitador es coma.
6. Si el archivo trae encabezados, activa la opción correspondiente.
7. Guarda.

Sugerencia de nombre:

```text
DS_SFTP_GlobalSuperstore_CSV
```

## Paso 14. Validar la vista previa del CSV

Antes de seguir:

1. Usa `Preview data` si ADF lo permite.
2. Verifica que las columnas se separen correctamente.
3. Confirma que no haya problemas de codificación o comillas.

## Paso 15. Crear el dataset parquet de destino

1. Crea un dataset nuevo de tipo `Azure Data Lake Storage Gen2`.
2. Selecciona formato `Parquet`.
3. Usa el linked service `LS_ADLS_BLL_PERSONAL`.
4. Selecciona el File System que creaste en tu Storage Account.
5. No fijes una ruta final completamente estática si quieres controlarla desde la actividad.
6. Guarda.

Sugerencia de nombre:

```text
DS_ADLS_Superstore_Parquet
```

## Fase 6. Crear el pipeline del reto

## Paso 16. Crear el pipeline

1. Crea un pipeline nuevo.
2. Ponle un nombre claro.

Ejemplo:

```text
PL_SFTP_Superstore_To_Parquet
```

## Paso 17. Agregar la actividad `Copy Data`

1. Arrastra una actividad `Copy data` al canvas.
2. Nómbrala:

```text
CPY_Superstore_To_Parquet
```

## Paso 18. Configurar el source

En la pestaña `Source`:

1. Selecciona el dataset `DS_SFTP_GlobalSuperstore_CSV`.
2. Verifica que ADF apunte al archivo correcto.
3. Confirma formato, delimitador y encabezados.

## Paso 19. Configurar el sink

En la pestaña `Sink`:

1. Selecciona `DS_ADLS_Superstore_Parquet`.
2. Define el File System correcto.
3. Configura el `folder path` como:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sftp/Global/Superstore
```

4. Configura el `file name` como:

```text
superstore2.parquet
```

## Paso 20. Configurar el mapeo

En `Mapping`:

1. Importa el esquema si ADF lo permite.
2. Revisa que los nombres de columnas sean válidos para parquet.
3. Si alguna columna trae caracteres problemáticos, corrígelo antes de ejecutar o usa nombres limpios.

## Fase 7. Ejecutar y validar

## Paso 21. Validar el pipeline

1. Haz `Validate`.
2. Corrige cualquier error de credenciales, datasets o ruta de salida.
3. Publica los cambios si ADF te lo requiere.

## Paso 22. Ejecutar en `Debug`

1. Ejecuta el pipeline en `Debug`.
2. Verifica que la lectura del archivo SFTP funcione.
3. Revisa que la escritura parquet termine sin errores.

## Paso 23. Revisar el archivo en tu Data Lake personal

Después del `Debug`, valida esto:

1. Existe la ruta esperada.
2. El archivo se llama `superstore2.parquet`.
3. El archivo quedó dentro de tu File System.
4. Los datos son legibles.

## Riesgos comunes en cuenta personal

### 1. Error de conectividad al SFTP

Si ADF no logra llegar al servidor SFTP, el pipeline no podrá leer el archivo aunque el diseño esté bien.

### 2. Delimitador o encabezados mal configurados

Eso provoca columnas corridas o datos corruptos al convertir a parquet.

### 3. Ruta final incorrecta

El reto exige una ruta exacta y un nombre de archivo fijo.

### 4. No usar parquet

El formato exigido por el reto es `.parquet`.

## Cómo explicarlo en la defensa

En el video conviene mostrarlo así:

1. La creación del Storage Account y del Data Factory.
2. El linked service al SFTP.
3. El linked service al Data Lake.
4. El dataset CSV de origen.
5. El dataset parquet de destino.
6. La actividad `Copy Data`.
7. La ejecución exitosa.
8. La validación del parquet en el Data Lake.

## Checklist final para ambiente personal nuevo

- Suscripción personal activa.
- Resource Group creado.
- Storage Account creada.
- `Hierarchical namespace` habilitado.
- File System creado.
- Azure Data Factory creado.
- Linked service a SFTP creado.
- Linked service a ADLS creado.
- Dataset CSV de origen creado.
- Dataset parquet de destino creado.
- `Copy Data` configurado.
- Ruta correcta.
- Archivo `superstore2.parquet` creado.
- Pipeline validado y ejecutado con éxito.