# Reto 1 - Paso a paso desde cero en Azure personal

## Objetivo

Construir un data pipeline en Azure Data Factory, partiendo de una suscripción personal nueva de Azure, para leer la tabla `BikeStores.sales.order_items`, filtrar los registros por el año y mes de la `FechaProceso`, y guardar el resultado en formato `.parquet` dentro de un Data Lake con una ruta dinámica.

## Supuesto de esta guía

Esta guía asume que:

1. Vas a trabajar en tu propia cuenta de Azure.
2. No tienes nada creado todavía para este reto.
3. Necesitas preparar desde cero el storage, el Data Factory y el pipeline.
4. Ya cuentas con las credenciales de la fuente SQL que vienen en el documento original del laboratorio.

## Qué pide exactamente el reto

Debes cumplir estas reglas:

1. Leer los datos de `BikeStores.sales.order_items`.
2. Filtrar por año y mes usando `order_date`.
3. La fecha no se escribe manualmente: debe salir de `BikeStores.dbo.Parametros` usando la clave `FechaProceso`.
4. El archivo final debe quedar en una ruta como esta:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sql/Sales/Order_Items/<YYYY>/order_items_<YYYYMMDD>.parquet
```

5. El folder `<YYYY>` y el nombre del archivo deben generarse dinámicamente.

## Arquitectura mínima que vas a crear

Para resolver este reto en una cuenta personal nueva, necesitas crear como mínimo:

1. Una suscripción de Azure activa.
2. Un Resource Group.
3. Una Storage Account con `Hierarchical namespace` habilitado.
4. Un File System o contenedor para usarlo como Data Lake.
5. Un Azure Data Factory.
6. Un linked service al SQL Server fuente.
7. Un linked service al Data Lake.
8. Los datasets.
9. El pipeline con `Lookup` y `Copy Data`.

## Resultado esperado

Al ejecutar el pipeline:

1. Se consulta la fecha de proceso en la tabla de parámetros.
2. Se calcula el año y el mes de esa fecha.
3. Se extraen solo los registros correspondientes a ese período.
4. Se genera un archivo parquet en una carpeta dinámica basada en la fecha.

## Fase 1. Preparar la cuenta personal de Azure

## Paso 1. Verificar que tu cuenta de Azure esté lista

Antes de crear recursos, confirma esto:

1. Tienes una cuenta de Azure activa.
2. Tu suscripción permite crear recursos.
3. Puedes entrar al portal en `https://portal.azure.com`.

Si todavía no tienes suscripción activa, primero debes crear una cuenta gratuita o una suscripción de pago antes de continuar.

## Paso 2. Elegir una región

Escoge una sola región para mantener simple el laboratorio y reducir costos.

Recomendación práctica:

1. Usa una región común como `East US` o `South Central US`.
2. Crea tanto el Storage como el Data Factory en la misma región.

## Paso 3. Crear un Resource Group

En Azure Portal:

1. Busca `Resource groups`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción.
4. Asigna un nombre claro.

Ejemplo:

```text
rg-bll-personal
```

5. Elige la región.
6. Crea el recurso.

## Fase 2. Crear el Data Lake desde cero

## Paso 4. Crear la Storage Account

En Azure Portal:

1. Busca `Storage accounts`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción y el Resource Group recién creado.
4. Elige un nombre único global.

Ejemplo:

```text
stbllpersonal001
```

5. Región: usa la misma del Resource Group.
6. Performance: `Standard`.
7. Redundancy: `LRS` para mantener bajo el costo.

## Paso 5. Habilitar Data Lake Gen2

Durante la creación de la Storage Account, asegúrate de activar:

```text
Hierarchical namespace
```

Eso convierte la cuenta en compatible con Azure Data Lake Storage Gen2. Si no activas esto, luego no tendrás la estructura esperada para el reto.

## Paso 6. Crear el File System del Data Lake

Cuando la Storage Account ya exista:

1. Entra al recurso.
2. Ve a `Containers` o `Storage browser`.
3. Crea un File System o contenedor.

Ejemplo:

```text
data
```

Puedes usar otro nombre, pero luego debes apuntar correctamente desde ADF.

## Paso 7. Definir la ruta base del laboratorio

Dentro del File System, el reto espera una estructura como esta:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sql/Sales/Order_Items/
```

No necesitas crear todas las carpetas manualmente desde ahora si ADF las va a generar, pero sí debes tener claro cuál será tu nombre exacto en la ruta.

## Fase 3. Crear Azure Data Factory

## Paso 8. Crear el recurso Azure Data Factory

En Azure Portal:

1. Busca `Data Factories`.
2. Haz clic en `Create`.
3. Usa la misma suscripción y el mismo Resource Group.
4. Pon un nombre único.

Ejemplo:

```text
adf-bll-personal-001
```

5. Región: usa la misma del Storage.
6. En `Git configuration`, puedes dejar `Configure Git later` para no complicar el arranque.
7. Crea el recurso.

## Paso 9. Abrir ADF Studio

Cuando termine la creación:

1. Entra al recurso.
2. Haz clic en `Launch studio`.

Toda la construcción del reto la harás dentro de ADF Studio.

## Fase 4. Preparar conexiones

## Paso 10. Confirmar qué necesitas para conectar a la base fuente

Para el Reto 1 necesitas conectarte al SQL Server externo descrito en la guía original del laboratorio.

Debes tener:

1. Servidor.
2. Puerto.
3. Base de datos.
4. Usuario.
5. Contraseña.
6. Configuración de cifrado indicada por el documento.

Si el servidor fuente no responde desde tu cuenta personal, el problema ya no será del pipeline sino de conectividad entre ADF y la fuente externa.

## Paso 11. Crear el linked service al SQL Server

En ADF Studio:

1. Ve a `Manage`.
2. Entra a `Linked services`.
3. Crea uno nuevo.
4. Selecciona `SQL Server`.
5. Configura los datos de conexión del documento original.
6. Usa la base de datos `Bikestores`.
7. Ajusta la encriptación según la guía del reto.
8. Prueba la conexión.
9. Guarda.

Sugerencia de nombre:

```text
LS_SQL_BikeStores
```

## Paso 12. Crear el linked service al Data Lake personal

1. En `Manage`, crea otro linked service.
2. Selecciona `Azure Data Lake Storage Gen2`.
3. Elige tu Storage Account personal.
4. Usa autenticación con tu cuenta o con la opción que ADF te permita de forma más simple.
5. Prueba la conexión.
6. Guarda.

Sugerencia de nombre:

```text
LS_ADLS_BLL_PERSONAL
```

## Fase 5. Crear datasets

## Paso 13. Crear el dataset para la tabla de parámetros

Debes leer esta tabla:

```sql
BikeStores.dbo.Parametros
```

En ADF:

1. Ve a `Author`.
2. Crea un dataset nuevo de tipo `SQL Server`.
3. Asócialo al linked service `LS_SQL_BikeStores`.
4. Si ADF te pide tabla, apunta a `dbo.Parametros`.
5. Guarda.

Sugerencia de nombre:

```text
DS_SQL_Parametros
```

## Paso 14. Crear el dataset para `order_items`

1. Crea otro dataset de tipo `SQL Server`.
2. Usa el linked service `LS_SQL_BikeStores`.
3. Apunta a `sales.order_items`.
4. Guarda.

Sugerencia de nombre:

```text
DS_SQL_OrderItems
```

## Paso 15. Crear el dataset sink parquet

1. Crea un dataset nuevo de tipo `Azure Data Lake Storage Gen2`.
2. Selecciona formato `Parquet`.
3. Usa el linked service `LS_ADLS_BLL_PERSONAL`.
4. Selecciona el File System que creaste en tu Storage Account.
5. No fijes una ruta final completamente estática si quieres que el pipeline la construya dinámicamente.
6. Guarda.

Sugerencia de nombre:

```text
DS_ADLS_OrderItems_Parquet
```

## Fase 6. Crear el pipeline del reto

## Paso 16. Crear el pipeline

1. Crea un pipeline nuevo.
2. Ponle un nombre claro.

Ejemplo:

```text
PL_SQL_OrderItems_To_Parquet
```

## Paso 17. Agregar el `Lookup` para obtener `FechaProceso`

1. Arrastra una actividad `Lookup` al canvas.
2. Nómbrala:

```text
LKP_FechaProceso
```

3. En `Settings`, selecciona el dataset `DS_SQL_Parametros`.
4. Activa `Use query`.
5. Usa una consulta parecida a esta:

```sql
SELECT CAST(Valor AS date) AS FechaProceso
FROM BikeStores.dbo.Parametros
WHERE Clave = 'FechaProceso'
```

6. Verifica que el `Lookup` devuelva una sola fila.

## Paso 18. Confirmar cómo leer el valor del `Lookup`

Normalmente el valor quedará disponible así:

```text
@activity('LKP_FechaProceso').output.firstRow.FechaProceso
```

Ese valor será la base para el filtro y para el nombre del archivo.

## Paso 19. Agregar la actividad `Copy Data`

1. Arrastra una actividad `Copy data`.
2. Conéctala después del `Lookup`.
3. Nómbrala:

```text
CPY_OrderItems_To_Parquet
```

## Paso 20. Configurar el source de `Copy Data`

En la pestaña `Source`:

1. Selecciona el dataset `DS_SQL_OrderItems`.
2. Activa `Use query`.
3. Usa una consulta dinámica o una consulta SQL que filtre por año y mes usando la `FechaProceso`.

## Paso 21. Ajuste importante sobre `order_date`

La tabla `order_items` normalmente no trae `order_date`; esa fecha suele estar en `sales.orders`.

Eso significa que, si tu esquema sigue la estructura típica de BikeStores, el filtro correcto debe hacerse con un `JOIN` entre `order_items` y `orders`, usando `o.order_date`.

## Paso 22. Consulta recomendada para el source

En ADF suele ser más estable construir el query con contenido dinámico. Un ejemplo es este:

```adf
@concat(
  'SELECT oi.* FROM BikeStores.sales.order_items oi INNER JOIN BikeStores.sales.orders o ON oi.order_id = o.order_id WHERE YEAR(o.order_date) = ',
  formatDateTime(activity(''LKP_FechaProceso'').output.firstRow.FechaProceso, 'yyyy'),
  ' AND MONTH(o.order_date) = ',
  int(formatDateTime(activity(''LKP_FechaProceso'').output.firstRow.FechaProceso, 'MM'))
)
```

Si ADF presenta problemas con saltos de línea, pégalo como una sola línea.

## Paso 23. Configurar el sink parquet

En la pestaña `Sink`:

1. Selecciona `DS_ADLS_OrderItems_Parquet`.
2. Indica el File System correcto.
3. Construye dinámicamente la carpeta y el nombre del archivo.

## Paso 24. Construir la ruta dinámica

La ruta esperada por el reto es:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sql/Sales/Order_Items/<YYYY>/order_items_<YYYYMMDD>.parquet
```

### Folder path

```adf
@concat(
  'bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Sql/Sales/Order_Items/',
  formatDateTime(activity(''LKP_FechaProceso'').output.firstRow.FechaProceso, 'yyyy')
)
```

### File name

```adf
@concat(
  'order_items_',
  formatDateTime(activity(''LKP_FechaProceso'').output.firstRow.FechaProceso, 'yyyyMMdd'),
  '.parquet'
)
```

Reemplaza `<Nombre_y_Apellidos_Colaborador>` por tu nombre real en el path.

## Paso 25. Configurar el mapeo

En `Mapping`:

1. Importa el esquema si ADF lo permite.
2. Revisa que los nombres de columnas sean válidos para parquet.
3. Si el `JOIN` agrega columnas que no necesitas, conserva solo `oi.*` o mapea únicamente las columnas del detalle.

## Fase 7. Ejecutar y validar

## Paso 26. Validar el pipeline

1. Haz `Validate`.
2. Corrige cualquier error de credenciales, expresiones dinámicas o datasets.
3. Publica los cambios si ADF te lo requiere antes de ejecutar.

## Paso 27. Ejecutar en `Debug`

1. Ejecuta el pipeline en `Debug`.
2. Revisa que el `Lookup` traiga una `FechaProceso` válida.
3. Revisa que el `Copy` copie solo el mes y año esperados.
4. Confirma que el parquet se cree en la carpeta correcta.

## Paso 28. Revisar el archivo en tu Data Lake personal

Después del `Debug`, entra a tu Storage Account y valida esto:

1. Existe la carpeta del año correcto.
2. El nombre del archivo sigue el patrón `order_items_YYYYMMDD.parquet`.
3. El archivo efectivamente quedó en tu File System.
4. Los datos pertenecen al mes y año de la `FechaProceso`.

## Costos y decisiones prácticas para cuenta personal

Para no gastar de más en este reto:

1. Usa una sola región.
2. Usa `LRS` en el Storage Account.
3. No crees recursos extra que no aporten al reto.
4. Evita habilitar servicios avanzados que no necesitas.
5. Elimina recursos cuando termines de grabar y validar si ya no los vas a usar.

## Riesgos comunes en cuenta personal

### 1. No tener Data Lake Gen2 habilitado

Si no activas `Hierarchical namespace`, luego tu Storage no quedará correctamente preparado como ADLS Gen2.

### 2. Error de conectividad a la base fuente

Aunque tu ADF esté bien creado, si la fuente externa no acepta la conexión desde tu entorno de Azure, el pipeline no podrá leer datos.

### 3. Ruta mal construida

El reto exige una convención exacta para carpeta y nombre del archivo.

### 4. Tomar la fecha manualmente

No debes inventar la fecha ni ponerla fija. Debe salir de `BikeStores.dbo.Parametros` con la clave `FechaProceso`.

### 5. Filtrar directamente con `order_items.order_date`

Ese campo puede no existir en `order_items`. Si no existe, debes unir con `sales.orders`.

## Cómo explicarlo en la defensa

En el video conviene mostrarlo así:

1. Que partiste de una cuenta personal sin recursos creados.
2. La creación del Storage Account con Data Lake Gen2.
3. La creación del Azure Data Factory.
4. Los linked services.
5. El `Lookup` de `FechaProceso`.
6. El `Copy Data` con el filtro por año y mes.
7. La construcción dinámica del path.
8. La ejecución exitosa.
9. La validación final del parquet en el Data Lake.

## Checklist final para ambiente personal nuevo

- Suscripción personal activa.
- Resource Group creado.
- Storage Account creada.
- `Hierarchical namespace` habilitado.
- File System creado.
- Azure Data Factory creado.
- Linked service a SQL Server creado.
- Linked service a ADLS creado.
- Dataset de `Parametros` creado.
- Dataset de `order_items` creado.
- Dataset sink parquet creado.
- `Lookup` de `FechaProceso` funcionando.
- `Copy Data` filtrando por año y mes.
- Ruta dinámica correcta.
- Nombre del archivo correcto.
- Pipeline validado y ejecutado con éxito.