# Reto 4 - Opcional - Paso a paso desde cero en Azure personal

## Objetivo

Construir un data pipeline en Azure Data Factory, partiendo de una suscripción personal de Azure, para leer la tabla `CHINOOK.INVOICE` desde IBM DB2 y guardarla como `.parquet` en tu Data Lake.

## Supuesto de esta guía

Esta guía asume que:

1. Vas a trabajar en tu propia cuenta de Azure.
2. No tienes nada creado todavía para este reto.
3. Necesitas preparar desde cero el storage, el Data Factory y el pipeline.
4. Ya cuentas con las credenciales de DB2 que vienen en el documento original del laboratorio.
5. Este reto es opcional.

## Qué pide exactamente el reto

Debes cumplir estas reglas:

1. Leer los datos de `CHINOOK.INVOICE` desde IBM DB2.
2. Guardar los datos en formato `.parquet`.
3. El archivo final debe quedar en esta ruta:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Db2/Chinook/Invoice/invoice.parquet
```

## Arquitectura mínima que vas a crear

Para resolver este reto en una cuenta personal nueva, necesitas crear como mínimo:

1. Una suscripción de Azure activa.
2. Un Resource Group.
3. Una Storage Account con `Hierarchical namespace` habilitado.
4. Un File System o contenedor para usarlo como Data Lake.
5. Un Azure Data Factory.
6. Un linked service a IBM DB2.
7. Un linked service al Data Lake.
8. Un dataset DB2 de origen.
9. Un dataset parquet de destino.
10. Un pipeline con una actividad `Copy Data`.

## Resultado esperado

Al ejecutar el pipeline:

1. Azure Data Factory se conecta a IBM DB2.
2. Lee la tabla `CHINOOK.INVOICE`.
3. Convierte el contenido a parquet.
4. Lo escribe en la ruta pedida por el reto.

## Fase 1. Preparar la cuenta personal de Azure

## Paso 1. Verificar que tu cuenta de Azure esté lista

Antes de crear recursos, confirma esto:

1. Tienes una cuenta de Azure activa.
2. Tu suscripción permite crear recursos.
3. Puedes entrar al portal en `https://portal.azure.com`.

## Paso 2. Elegir una región

Escoge una sola región para mantener simple el laboratorio y reducir costos.

## Paso 3. Crear un Resource Group

En Azure Portal:

1. Busca `Resource groups`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción.
4. Asigna un nombre claro.
5. Elige la región.
6. Crea el recurso.

## Fase 2. Crear el Data Lake desde cero

## Paso 4. Crear la Storage Account

En Azure Portal:

1. Busca `Storage accounts`.
2. Haz clic en `Create`.
3. Selecciona tu suscripción y el Resource Group recién creado.
4. Elige un nombre único global.
5. Región: usa la misma del Resource Group.
6. Performance: `Standard`.
7. Redundancy: `LRS`.
8. Activa `Hierarchical namespace`.

## Paso 5. Crear el File System del Data Lake

Cuando la Storage Account ya exista:

1. Entra al recurso.
2. Ve a `Containers` o `Storage browser`.
3. Crea un File System o contenedor.

Ejemplo:

```text
data
```

## Fase 3. Crear Azure Data Factory

## Paso 6. Crear el recurso Azure Data Factory

En Azure Portal:

1. Busca `Data Factories`.
2. Haz clic en `Create`.
3. Usa la misma suscripción y el mismo Resource Group.
4. Pon un nombre único.
5. Región: usa la misma del Storage.
6. En `Git configuration`, puedes dejar `Configure Git later`.
7. Crea el recurso.

## Paso 7. Abrir ADF Studio

Cuando termine la creación:

1. Entra al recurso.
2. Haz clic en `Launch studio`.

## Fase 4. Preparar conexiones

## Paso 8. Confirmar qué necesitas para conectar a DB2

Para el Reto 4 necesitas conectarte al servidor IBM DB2 descrito en la guía original.

Debes tener:

1. Host o servidor.
2. Puerto.
3. Base de datos `SAMPLE`.
4. Usuario.
5. Contraseña.
6. `Package Collection: NULLID`.

## Paso 9. Crear el linked service a IBM DB2

En ADF Studio:

1. Ve a `Manage`.
2. Entra a `Linked services`.
3. Crea uno nuevo.
4. Busca el conector `IBM DB2` o `Db2`, según cómo aparezca en tu ADF.
5. Configura host, puerto, base de datos, usuario, contraseña y `Package Collection` si el conector lo permite.
6. Prueba la conexión.
7. Guarda.

Sugerencia de nombre:

```text
LS_DB2_Chinook
```

## Paso 10. Crear el linked service al Data Lake personal

1. En `Manage`, crea otro linked service.
2. Selecciona `Azure Data Lake Storage Gen2`.
3. Elige tu Storage Account personal.
4. Usa el método de autenticación más simple disponible en ADF.
5. Prueba la conexión.
6. Guarda.

Sugerencia de nombre:

```text
LS_ADLS_BLL_PERSONAL
```

## Fase 5. Crear datasets

## Paso 11. Crear el dataset DB2 de origen

1. Ve a `Author`.
2. Crea un dataset nuevo del tipo asociado al conector de IBM DB2.
3. Asócialo al linked service `LS_DB2_Chinook`.
4. Apunta a la tabla `CHINOOK.INVOICE`.
5. Guarda.

Sugerencia de nombre:

```text
DS_DB2_Invoice
```

## Paso 12. Crear el dataset parquet de destino

1. Crea un dataset nuevo de tipo `Azure Data Lake Storage Gen2`.
2. Selecciona formato `Parquet`.
3. Usa el linked service `LS_ADLS_BLL_PERSONAL`.
4. Selecciona el File System que creaste.
5. No fijes la ruta final si la quieres controlar desde la actividad.
6. Guarda.

Sugerencia de nombre:

```text
DS_ADLS_Invoice_Parquet
```

## Fase 6. Crear el pipeline del reto

## Paso 13. Crear el pipeline

1. Crea un pipeline nuevo.
2. Ponle un nombre claro.

Ejemplo:

```text
PL_DB2_Invoice_To_Parquet
```

## Paso 14. Agregar la actividad `Copy Data`

1. Arrastra una actividad `Copy data` al canvas.
2. Nómbrala:

```text
CPY_DB2_Invoice_To_Parquet
```

## Paso 15. Configurar el source

En la pestaña `Source`:

1. Selecciona el dataset `DS_DB2_Invoice`.
2. Si ADF lo permite, usa la tabla directamente.
3. Si necesitas más control, usa un query simple como:

```sql
SELECT *
FROM CHINOOK.INVOICE
```

## Paso 16. Configurar el sink

En la pestaña `Sink`:

1. Selecciona `DS_ADLS_Invoice_Parquet`.
2. Define el File System correcto.
3. Configura el `folder path` como:

```text
bllengineer/Nivel1/<Nombre_y_Apellidos_Colaborador>/Db2/Chinook/Invoice
```

4. Configura el `file name` como:

```text
invoice.parquet
```

## Paso 17. Configurar el mapeo

En `Mapping`:

1. Importa el esquema si ADF lo permite.
2. Revisa que los nombres de columnas sean válidos para parquet.
3. Confirma que los tipos de datos se conviertan correctamente.

## Fase 7. Ejecutar y validar

## Paso 18. Validar el pipeline

1. Haz `Validate`.
2. Corrige cualquier error de conector, credenciales o ruta.
3. Publica los cambios si ADF te lo requiere.

## Paso 19. Ejecutar en `Debug`

1. Ejecuta el pipeline en `Debug`.
2. Verifica que la lectura desde DB2 funcione.
3. Revisa que la escritura parquet termine sin errores.

## Paso 20. Revisar el archivo en tu Data Lake personal

Después del `Debug`, valida esto:

1. Existe la ruta esperada.
2. El archivo se llama `invoice.parquet`.
3. El archivo quedó dentro de tu File System.
4. Los datos son legibles.

## Riesgos comunes en cuenta personal

### 1. Error de conectividad a DB2

Si ADF no logra llegar al servidor DB2, el pipeline no podrá leer datos aunque el diseño esté bien.

### 2. Configuración incompleta del conector

DB2 suele ser más sensible que otras fuentes a parámetros como base de datos, puerto o package collection.

### 3. Ruta final incorrecta

El reto exige una ruta exacta y un nombre de archivo fijo.

## Cómo explicarlo en la defensa

En el video conviene mostrarlo así:

1. La creación del Storage Account y del Data Factory.
2. El linked service a DB2.
3. El dataset de origen.
4. El dataset parquet de destino.
5. La actividad `Copy Data`.
6. La ejecución exitosa.
7. La validación del archivo en el Data Lake.

## Checklist final para ambiente personal nuevo

- Suscripción personal activa.
- Resource Group creado.
- Storage Account creada.
- `Hierarchical namespace` habilitado.
- File System creado.
- Azure Data Factory creado.
- Linked service a DB2 creado.
- Linked service a ADLS creado.
- Dataset DB2 de origen creado.
- Dataset parquet de destino creado.
- `Copy Data` configurado.
- Ruta correcta.
- Archivo `invoice.parquet` creado.
- Pipeline validado y ejecutado con éxito.