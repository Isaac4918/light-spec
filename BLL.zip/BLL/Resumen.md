# Resumen indispensable

## Lo mínimo que debes entender

1. Un pipeline de datos mueve información desde una fuente hasta un destino.
2. En estos retos, las fuentes pueden ser SQL Server, SFTP, una API o DB2.
3. El destino final casi siempre es un Data Lake en Azure.
4. La herramienta principal para construir los pipelines es Azure Data Factory.

## Lo mínimo que debes tener en Azure

1. Una suscripción activa.
2. Un `Resource Group`.
3. Una `Storage Account` con `Hierarchical namespace` activado.
4. Un `File System` o contenedor.
5. Un `Azure Data Factory`.

## Lo mínimo dentro de Azure Data Factory

1. Un `Linked Service` a la fuente.
2. Un `Linked Service` al Data Lake.
3. Un `Dataset` de origen.
4. Un `Dataset` de destino.
5. Un `Pipeline`.
6. Casi siempre una actividad `Copy Data`.
7. En el Reto 1 también una actividad `Lookup`.

## Qué hace cada cosa

1. `Linked Service`: la conexión.
2. `Dataset`: el dato que vas a leer o escribir.
3. `Pipeline`: el flujo completo.
4. `Copy Data`: copia datos de un origen a un destino.
5. `Lookup`: lee un valor pequeño, como una fecha.

## Formatos que debes diferenciar

1. `CSV`: archivo de texto con columnas separadas por comas.
2. `JSON`: archivo útil para datos con estructura anidada, muy común en APIs.
3. `Parquet`: formato eficiente para almacenar datos tabulares.

## Regla práctica para elegir formato

1. Si el origen es tabular, normalmente conviene `parquet`.
2. Si el origen trae objetos o listas anidadas, normalmente conviene `json`.

## Lo indispensable por reto

### Reto 1

1. Leer `FechaProceso` desde `dbo.Parametros`.
2. Filtrar los datos por año y mes.
3. Guardar en parquet con ruta dinámica.
4. Si `order_date` no está en `order_items`, usar `JOIN` con `orders`.

### Reto 2

1. Leer `Global_Superstore2.csv` desde SFTP.
2. Confirmar delimitador y encabezados.
3. Guardar en parquet.

### Reto 3

1. Consumir la API con `GET`.
2. Revisar la estructura de la respuesta.
3. Guardar normalmente en `JSON`.

### Reto 4 opcional

1. Leer `CHINOOK.INVOICE` desde DB2.
2. Guardar en parquet.

## Lo que no debes olvidar

1. Validar conexiones antes de ejecutar.
2. Revisar que la ruta final sea exactamente la que pide el reto.
3. Revisar que el archivo final exista en el Data Lake.
4. Revisar que el contenido tenga sentido.

## Si solo recuerdas una idea

Debes conectar una fuente, leer datos correctamente, guardarlos en el formato correcto y dejarlos en la ruta exacta que pide el reto.